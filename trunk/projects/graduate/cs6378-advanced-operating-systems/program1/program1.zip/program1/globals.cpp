unsigned int node_network_size = 0;
unsigned int node_id = 0;
unsigned int node_network_master = 0;

bool         node_computation_complete = false;
unsigned int network_nodes_completed = 0;