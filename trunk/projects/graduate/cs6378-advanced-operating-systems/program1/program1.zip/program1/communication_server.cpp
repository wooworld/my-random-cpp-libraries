#include "communication_server.h"

#include <netdb.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include "str_manip.h"
#include <iostream>
#include <string>
#include <fstream>
#include <unistd.h>
#include "globals.h"

using std::cout;
using std::endl;
using std::string;
using std::ifstream;

// The threads for the communication server
comm_recv_thread_t          comm_listen_thread_id;
comm_thread_t               comm_recv_parse_thread_id;
vector<comm_recv_thread_t>  comm_recv_thread_ids;
comm_thread_t               comm_send_thread_id;

// Queues for message passing between threads
concurrent_queue<msg_t> comm_send_q;
concurrent_queue<msg_t> comm_recv_q;
CriticalSectionTracker  comm_cs;
concurrent_queue<cs_stat_entry_t> comm_cs_log;

int                    comm_port = -1;

vector<node_contact_t> comm_contacts;
ConditionVariable      comm_network_joined;
Mutex                  comm_network_joined_mutex;

ConditionVariable      comm_computation_complete;
Mutex                  comm_computation_complete_mutex;

// Communication server setup
int comm_start( char* config_file_path ) {
  int error  = 0;

  if ( config_file_path == NULL ) {
    cout << "Invalid config file path" << endl;
    return -1;
  }
  
  // Open configuration file, read only
  string line;
  ifstream config_file( config_file_path, ios::in );
  
  if ( config_file.is_open() ) {
    // Read comms port
    std::getline( config_file, line );
    comm_port = str_to_uint( line );
    
    // Read network master
    std::getline( config_file, line );
    node_network_master = str_to_uint( line );
    
    node_contact_t curr_node;
    curr_node.sockfd = -1;
    
    // Read <node ID, address> pairs
    while ( config_file.good() ) {
      std::getline( config_file, line );
      curr_node.id = str_to_uint( line );
      
      std::getline( config_file, line );
      curr_node.address = line;
      
      // Don't add an entry for ourselves to the contacts list
      if ( curr_node.id == node_id ) {
        continue;
      }
      
      error = comm_add_contact( curr_node );
      if ( error == -1 ) {
        break;
      }     
    }
    
    // Finished reading from file
    config_file.close();
  
    node_network_size = comm_contacts.size() + 1;
    
    // Initialize the critical section stuff
    comm_cs.rep_deferred.resize( node_network_size, false );
    comm_cs.mutex_tokens.resize( node_network_size, false );
    comm_cs.mutex_tokens[node_id] = true;
    
    // Spawn listener thread
    error = pthread_create( &(comm_listen_thread_id.id),
                            NULL,
                            comm_listen_thread_start,
                            &comm_listen_thread_id );
    if ( error != 0 ) {
      comm_listen_thread_id.state = T_STATE_STOP;
      cout << "communication_server: failed to create listen thread" << endl;
      return -1;
    }
    comm_listen_thread_id.state = T_STATE_ACTIVE;
    
    // Spawn receive parser thread
    error = pthread_create( &(comm_recv_parse_thread_id.id),
                            NULL,
                            comm_recv_parse_thread_start,
                            &comm_recv_parse_thread_id );
    if ( error != 0 ) {
      comm_recv_parse_thread_id.state = T_STATE_STOP;
      cout << "communication_server: failed to create receive parser thread" << endl;
      return -1;
    }
    comm_recv_parse_thread_id.state = T_STATE_ACTIVE;
    
    // Open a connection to all remote addresses (previously read from file)
    error = comm_connect_all();
    if ( error != 0 ) {
      cout << "communication_server: failed to connect to all remote addresses" << endl;
      return -1;
    }
    
    // Spawn sender thread
    error = pthread_create( &(comm_send_thread_id.id),
                            NULL,
                            comm_send_thread_start,
                            &comm_send_thread_id );
    if ( error != 0 ) {
      comm_send_thread_id.state = T_STATE_STOP;
      cout << "communication_server: failed to create listen thread" << endl;
      return -1;
    }
    comm_send_thread_id.state = T_STATE_ACTIVE;
    
    cout << "Communication server started" << endl;  
    
    error = comm_join_network();
    if ( error != 0 ) {
      cout << "communication_server: failed to join the network" << endl;
      return -1;
    }
  }
  
  else {
    error = -1;
  }

  return error;
}

int comm_add_contact( const node_contact_t& contact ) {
  // Only add node contact if it doesn't already exist
  for ( unsigned int i = 0; i < comm_contacts.size(); i++ ) {
    if ( comm_contacts[i].id == contact.id ) {
      cout << "Contact already exists" << endl;
      return -1;
    }
  }
  
  comm_contacts.push_back( contact );

  return 0;
}

int comm_connect_once( string address ) {
  int sockfd = -1;
  struct addrinfo hints, *server_info, *p;

  memset( &hints, 0, sizeof(hints) );
  hints.ai_family   = AF_UNSPEC;   // IPv4 or IPv6 don't care
  hints.ai_socktype = SOCK_STREAM; // TCP
  
  // Get address info of remote address
  if ( getaddrinfo( address.c_str(), int_to_str(comm_port).c_str(), &hints, &server_info ) != 0 ) {
    ::freeaddrinfo( server_info );
    cout << "communication_server: Couldn't get remote address info" << endl;
    return -1;
  }

  // loop through all the results and connect to the first we can
  for( p = server_info; p != NULL; p = p->ai_next ) {
    sockfd = ::socket( p->ai_family, p->ai_socktype, p->ai_protocol );
    if ( sockfd == -1 ) {
      continue; 
    }

    if ( ::connect( sockfd, p->ai_addr, p->ai_addrlen ) == -1 ) {
      continue;
    }

    break;
  }

  if ( p == NULL ) {
    cout << "communication_server: couldn't parse remote address info" << endl;
    ::freeaddrinfo( server_info );
    return -1;
  }

  ::freeaddrinfo( server_info );
  
  return sockfd;
}

int comm_connect_until( string address ) {
  int sockfd = -1;
  struct addrinfo hints, *server_info, *p;

  memset( &hints, 0, sizeof(hints) );
  hints.ai_family   = AF_UNSPEC;   // IPv4 or IPv6 don't care
  hints.ai_socktype = SOCK_STREAM; // TCP
  
  int error = 0;
  
  do {
    // Get address info of remote address
    error = ::getaddrinfo( address.c_str(), int_to_str(comm_port).c_str(), &hints, &server_info );
    
    // If the get failed, wait one second and try again
    if ( error != 0 ) {
      cout << "communication_server: Couldn't get remote address info. retrying..." << endl;
      sleep( 1 );
    }
  } while ( error != 0 );
  
  do {
    // loop through all the results and connect to the first we can
    for( p = server_info; p != NULL; p = p->ai_next ) {
      sockfd = ::socket( p->ai_family, p->ai_socktype, p->ai_protocol );
      if ( sockfd == -1 ) {
        continue; 
      }

      if ( ::connect( sockfd, p->ai_addr, p->ai_addrlen ) == -1 ) {
        continue;
      }

      break;
    }

    // If the parsing failed, wait one second and try again
    if ( p == NULL ) {
      cout << "communication_server: couldn't parse remote address info" << endl;
      sleep( 1 );
    }
  } while ( p == NULL );

  ::freeaddrinfo( server_info );
  
  return sockfd;
}

int comm_connect_all() {  
  for ( unsigned int i = 0; i < comm_contacts.size(); i++ ) {
    comm_contacts[i].sockfd = comm_connect_until( comm_contacts[i].address );
  }
  
  return 0;
}

int comm_bind_once( int port ) {
  int sockfd = -1, yes = 1;
  struct addrinfo hints, *server_info, *p;

  memset( &hints, 0, sizeof(hints) );
  hints.ai_family   = AF_UNSPEC;   // IPv4 or IPv6 don't care
  hints.ai_socktype = SOCK_STREAM; // TCP
  hints.ai_flags    = AI_PASSIVE;  // Use this IP

  int error =  0;
  
  if ( ::getaddrinfo( NULL, int_to_str(comm_port).c_str(), &hints, &server_info ) != 0 ) {
    freeaddrinfo( server_info );
    cout << "communication_server: Couldn't get local address info" << endl;
    return -1;
  }

  // loop through all the results and connect to the first we can
  for( p = server_info; p != NULL; p = p->ai_next ) {
    sockfd = ::socket( p->ai_family, p->ai_socktype, p->ai_protocol );
    if ( sockfd == -1 ) {
      continue; 
    }
    
    if ( ::setsockopt( sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int) ) == -1 ) {
      // ?
    }

    if ( ::bind( sockfd, p->ai_addr, p->ai_addrlen ) == -1 ) {
      continue;
    }

    break;
  }

  if ( p == NULL ) {
    cout << "communication_server: couldn't bind to local address:" << comm_port << endl;
    ::freeaddrinfo( server_info );
    return -1;
  }

  ::freeaddrinfo( server_info );
  
  if ( ::listen( sockfd, 15 ) == -1 ) {
    cout << "communication_server: couldn't listen on port " << comm_port << endl;
  }
  
  return sockfd;
}

int comm_join_network() {
  msg_t join_msg;
  join_msg.msg_type = MSG_T_JOIN;
  
  // Broadcast that this node is ready to join the network
  comm_broadcast( join_msg );
  
  // Wait until all other nodes have broadcast as well
  comm_network_joined.wait( comm_network_joined_mutex );
  
  return 0;
}

// Thread entry functions
void* comm_listen_thread_start( void* data ) {
  comm_recv_thread_t* my_info = reinterpret_cast<comm_recv_thread_t*>(data);
  int newfd = -1, error = 0;
  struct sockaddr_storage remote_addr;
  socklen_t sin_size = sizeof(remote_addr);
  
  my_info->sockfd = comm_bind_once( comm_port );
  if ( my_info->sockfd < 0 ) {
    cout << "comm_listen_thread_start couldn't bind" << endl;
    return NULL;
  }
  
  // Accept loop
  // Communication hasn't been stopped
  while ( my_info->state == T_STATE_ACTIVE ) {
    newfd = ::accept( my_info->sockfd, (struct sockaddr*)&remote_addr, &sin_size );
    if ( newfd == -1 ) {
      cout << "comm_listen_thread_start couldn't accept" << endl;
      continue;
    }
    
    // Spawn receiver thread 
    comm_recv_thread_t new_thread;
    comm_recv_thread_ids.push_back( new_thread );
    
    
    comm_recv_thread_ids[comm_recv_thread_ids.size()-1].sockfd = newfd;
    error = pthread_create( &(comm_recv_thread_ids[comm_recv_thread_ids.size()-1].id),
                            NULL,
                            comm_recv_thread_start,
                            &comm_recv_thread_ids[comm_recv_thread_ids.size()-1] );
    
    if ( error != 0 ) {
      comm_recv_thread_ids[comm_recv_thread_ids.size()-1].state = T_STATE_STOP;
      cout << "communication_server: failed to create receive thread" << endl;
    }
    
    else {
      comm_recv_thread_ids[comm_recv_thread_ids.size()-1].state = T_STATE_ACTIVE;
    }
  }
  
  ::close( my_info->sockfd );

  return NULL;
}

void* comm_recv_thread_start( void* data ) {
  comm_recv_thread_t* my_info = reinterpret_cast<comm_recv_thread_t*>(data);
  //char   incoming_buf[sizeof(msg_t)];
  char   incoming_buf[1500];
  msg_t* incoming;
  int    error = 0;
  
  // Receive loop
  // Communication hasn't been stopped
  while ( my_info->state == T_STATE_ACTIVE ) {
    int bytes = ::recv( my_info->sockfd, incoming_buf, sizeof(incoming_buf), 0 );
    
    // Normal receive
    if ( bytes > 0 ) {
      incoming = reinterpret_cast<msg_t*>(incoming_buf);
      comm_recv_q.push( *incoming );
    }
    
    // Connection closed
    else if ( bytes <= 0 ) {
      cout << "Received message of size <= 0. Terminating receive thread..." << endl;
      my_info->state = T_STATE_STOP;
      break;
    }
  }
  
  ::close( my_info->sockfd );
  
  return NULL;
}

void* comm_recv_parse_thread_start( void* data ) {
  comm_thread_t* my_info = reinterpret_cast<comm_thread_t*>(data);
  int network_join_count = 1;
  int computation_complete_count = 0;
  int token_count = 0;
  msg_t incoming;
  int error = 0;
  bool defer_it;
  
  // Parse loop
  // Communication hasn't been stopped
  while ( my_info->state == T_STATE_ACTIVE ) {
    incoming = comm_recv();
    
    //print_recv_msg( incoming );
    
    if ( incoming.msg_type == MSG_T_REQUEST_CS ) {  
      comm_cs.shared_vars.lock();
      // Calculate our new sequence number
      comm_cs.max_seq_num = fun::max( comm_cs.max_seq_num, incoming.ts );
      
      // Determine if a reply should be deferred
      defer_it = (comm_cs.requesting_cs
                 && ( incoming.ts > comm_cs.seq_num
                      || ( (incoming.ts == comm_cs.seq_num) && (incoming.send_ID > node_id) ) ) );
      
      // Defer the reply
      if ( defer_it ) {
        comm_cs.rep_deferred[incoming.send_ID] = true;
      }
      
      // Send the reply
      else {
        comm_cs.mutex_tokens[incoming.send_ID] = false;
        msg_t outgoing;
        outgoing.dest_ID = incoming.send_ID;
        outgoing.msg_type = MSG_T_REPLY_CS;
        outgoing.ts = comm_cs.seq_num;
        comm_send( outgoing );
      }
      comm_cs.shared_vars.unlock();
    }
    
    else if ( incoming.msg_type == MSG_T_REPLY_CS ) { 
      comm_cs.shared_vars.lock();
      comm_cs.mutex_tokens[incoming.send_ID] = true;
      token_count = 0;
      
      // Determine if this node has permission from all nodes to enter CS
      for ( unsigned int i = 0; i < comm_cs.mutex_tokens.size(); i++ ) {
        if ( comm_cs.mutex_tokens[i] ) {
          token_count++;
        }
      }
      comm_cs.shared_vars.unlock();
      
      if ( token_count == node_network_size ) {
        comm_cs.entry_ok.broadcast();
      }
    }
    
    else if ( incoming.msg_type == MSG_T_NODE_COMPUTATION_COMPLETE ) {
      network_nodes_completed++;
      if ( network_nodes_completed == comm_contacts.size()
        && node_computation_complete
        && node_id == 0 ) {
        comm_computation_complete.broadcast();
      }
    }
    
    else if ( incoming.msg_type == MSG_T_NETWORK_COMPUTATION_COMPLETE ) {
      comm_computation_complete.broadcast();
    }
    
    else if ( incoming.msg_type == MSG_T_RESTART ) {
      // nothing...
    }
    
    else if ( incoming.msg_type == MSG_T_JOIN ) {
      network_join_count++;
      if ( network_join_count == node_network_size ) {
        //cout << "The network has been globally set up. Notifying all involved" << endl;
        comm_network_joined.broadcast();
      }
    }
    
    else if ( incoming.msg_type == MSG_T_END ) {
      // nothing...
    }
    
    else if ( incoming.msg_type == MSG_T_TERMINATE ) {
      my_info->state = T_STATE_STOP;
    }
    
    else if ( incoming.msg_type == MSG_T_FINAL ) {
      // nothing...
    }
    
    else {
      // Nothing...
    }
  }
  
  return NULL;
}

void* comm_send_thread_start( void* data ) {
  comm_thread_t* my_info = reinterpret_cast<comm_thread_t*>(data);
  msg_t outgoing;
  int error = 0;
  int dest_sockfd = -1;
  
  // Send loop
  // Communication hasn't been stopped
  while ( my_info->state == T_STATE_ACTIVE ) {
    comm_send_q.wait_and_pop( outgoing );
    
    dest_sockfd = -1;
    
    // Check to ensure outgoing's destination is known and its sockfd is valid
    for ( unsigned int i = 0; i < comm_contacts.size(); i++ ) {
      if ( (comm_contacts[i].id == outgoing.dest_ID)
        && (comm_contacts[i].sockfd > 0) ) {
        dest_sockfd = comm_contacts[i].sockfd;
        break;
      }
    }
    
    if ( dest_sockfd != -1 ) {
      //print_send_msg( outgoing );
      // Send the message
      error = ::send( dest_sockfd, &outgoing, sizeof(outgoing), 0 );
      if ( error == -1 ) {
        cout << "communication_server: failed to send message" << endl;
      }
    }
  }

  return NULL;
}

// Server interaction functions
int comm_send( msg_t msg ) {
  msg.send_ID = node_id;
  comm_send_q.push( msg );

  return 0;
}

int comm_broadcast( msg_t msg ) {
  int error = 0;
  
  msg_t outgoing = msg;
  outgoing.send_ID = node_id;
  
  // Loop over contacts and send msg to each one
  for ( unsigned int i = 0; i < comm_contacts.size(); i++ ) {
    outgoing.dest_ID = comm_contacts[i].id;
    comm_send( outgoing );
  }

  return error;
}

msg_t comm_recv() {
  msg_t temp;
  
  comm_recv_q.wait_and_pop( temp );
  
  return temp;
}

int comm_stop() {
  // Mark all threads STOP
  comm_listen_thread_id.state = T_STATE_STOP;
  comm_recv_parse_thread_id.state = T_STATE_STOP;
  comm_send_thread_id.state = T_STATE_STOP;
  for ( unsigned int i = 0; i < comm_recv_thread_ids.size(); i++ ) {
    comm_recv_thread_ids[i].state = T_STATE_STOP;
  }
  
  // Close sockets threads are working with. 
  // This gets the receiver threads and the listener thread off the blocking 
  // accept() and recv() calls
  ::close( comm_listen_thread_id.sockfd );
  for ( unsigned int i = 0; i < comm_recv_thread_ids.size(); i++ ) {
    ::close( comm_recv_thread_ids[i].state );
  }
  for ( unsigned int i = 0; i < comm_contacts.size(); i++ ) {
    ::close( comm_contacts[i].sockfd );
  }
  
  // Push an execution STOP message into the send and recv queues
  // This gets the receiver parser thread and the sending thread off the blocked
  // wait_and_pop() calls
  msg_t terminate;
  terminate.msg_type = MSG_T_TERMINATE;
  comm_recv_q.push( terminate );
  comm_send_q.push( terminate );
  
  // Join all threads
  pthread_join( comm_listen_thread_id.id, NULL );
  pthread_join( comm_recv_parse_thread_id.id, NULL );
  pthread_join( comm_send_thread_id.id, NULL );
  for ( unsigned int i = 0; i < comm_recv_thread_ids.size(); i++ ) {
    pthread_join( comm_recv_thread_ids[i].id, NULL );
  }
  
  return 0;
}

int comm_request_cs() {  
  // Record start time of request
  cs_stat_entry_t curr_request;
  timeval start;
  timeval end;
  gettimeofday(&start,NULL);
  
  comm_cs.shared_vars.lock();
  
  int req_cnt = 0;
  comm_cs.requesting_cs = true;
  comm_cs.seq_num = comm_cs.max_seq_num + 1;
  msg_t outgoing;
  outgoing.msg_type = MSG_T_REQUEST_CS;
  outgoing.ts = comm_cs.seq_num;
  
  // Send request messages to all nodes required
  for ( unsigned int i = 0; i < comm_cs.mutex_tokens.size(); i++ ) {
    if ( !comm_cs.mutex_tokens[i] ) {
      req_cnt++;
      outgoing.dest_ID = i;
      comm_send( outgoing );
    }
  }
  
  curr_request.msg_count = req_cnt * 2;   // total exchanged = requests + replies (should receive 1 rep for each req)
  curr_request.seq_num = comm_cs.seq_num; // sequence number of request made
  
  comm_cs.shared_vars.unlock();
  
  // If no requests were made, don't wait on any replies
  if ( req_cnt > 0 ) {
    comm_cs.entry_ok.wait( comm_cs.entry_ok_mutex );
  }
  
  // Record grant time of request
  gettimeofday(&end,NULL);
  
  timeval res;
  timersub(&end, &start, &res);
  
  // Record the request blocked/waiting time in seconds
  curr_request.wait_time = ( res.tv_sec + res.tv_usec / 1000000.0 );
  
  cout << "cs log entry: " << "seq_num " << curr_request.seq_num
       << " wait_time = " << curr_request.wait_time
       << " msg_count = " << curr_request.msg_count << endl;
  
  comm_cs_log.push( curr_request );
  
  return 0;
}

int comm_release_cs() {  
  comm_cs.shared_vars.lock();
  comm_cs.requesting_cs = false;
  
  msg_t outgoing;
  outgoing.msg_type = MSG_T_REPLY_CS;
  outgoing.ts       = comm_cs.seq_num;
  
  // Send deferred replies
  for ( unsigned int i = 0; i < comm_cs.rep_deferred.size(); i++ ) {
    if ( comm_cs.rep_deferred[i] ) {
      outgoing.dest_ID = i;
      comm_cs.mutex_tokens[i] = false;
      comm_send( outgoing );
    }
  }

  comm_cs.shared_vars.unlock();
  
  return 0;
}