extern unsigned int node_network_size;
extern unsigned int node_id;
extern unsigned int node_network_master;

extern bool         node_computation_complete;
extern unsigned int network_nodes_completed;