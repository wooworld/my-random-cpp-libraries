#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <pthread.h>
#include "NaiveConcurrentQueue.h"
#include "network_constructs.h"

// Tracks thread ID and execution state
typedef struct {
  pthread_t id;
  thread_state_t state;
} calc_thread_t;

// The single calculation thread ID
extern calc_thread_t           calc_thread_id;

// Calculator spawn calculation thread and begin calculation
int calc_start();

// Thread entry functions
void* calc_thread_start( void* data );

// Wait x amount of milliseconds
void calc_wait_duration( unsigned int duration );

// Wait a random amount of milliseconds between min and max
void calc_wait_between( unsigned int min, unsigned int max );

// Wait for the calculation to complete
void calc_to_completion();

// Calculator interaction functions
int calc_stop();

#endif